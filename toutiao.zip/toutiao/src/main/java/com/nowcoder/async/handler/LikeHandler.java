package com.nowcoder.async.handler;

import com.nowcoder.async.EventHandler;
import com.nowcoder.async.EventModel;
import com.nowcoder.async.EventType;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;


@Component
public class LikeHandler implements EventHandler {
    @Override
    public void doHandle(EventModel eventModel){

        System.out.println("like...");
    }

    @Override
    public List<EventType> getSupportsEventType() {
        return Arrays.asList(EventType.LIKE);
    }
}
